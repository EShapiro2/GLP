# GLP Source Files for Nested Structure Architecture Design

## Context

This package contains the essential GLP compiler and runtime source files needed to design a solution for nested structure support with variables.

## Current Status

✅ **Working (90% of cases):**
- Simple structures with variables: `bar(X)`, `merge([],[],X)`
- Metainterpreter with single-level goals
- Test cases: `runA(X)`, `run3(Y)`, `run4(Z)`, `run6(A)`, `test_struct(Z)` all pass

⚠️ **Not Working (nested structures):**
- Conjunctions with shared variables: `(merge([],[],Xs1), merge([],Xs1?,Ys))`
- Test cases: `run2(X)`, `test_conj(Z)` return `<unbound>`

## Problem Statement

**Compiler emits:** `PutStructure(',', 2, -1)` for nested conjunction (the `-1` signals "nested")
**Runtime issue:** Only supports building one structure at a time via `cx.currentStructure`
**Need:** Architecture to build nested structures with proper variable sharing

## Key Files

### Compiler
- **codegen.dart** (lines 646-685) - `_generateStructureElementInBody()` method handles variables
- **glp-compiler-spec.md** - Complete compiler specification

### Runtime
- **runner.dart** (lines 1514-1657) - `PutStructure`, `SetWriter`, `SetReader` handlers
- **opcodes.dart** - Bytecode instruction definitions
- **machine_state.dart** - ExecutionContext structure (has `currentStructure`, needs stack?)

### Data Structures
- **terms.dart** - Term types: `VarTerm`, `StructTerm`, `WriterTerm`, `ReaderTerm`
- **heap_v2.dart** - Writer/Reader cell management for SRSW dataflow

### Documentation
- **NONGROUND_STRUCTURE_IMPLEMENTATION_REPORT.md** - Complete implementation history
- **glp-bytecode-v216-complete.md** - Bytecode semantics

### Test Cases
- **run2.glp** - Full metainterpreter with nested structure test
- **test_struct_var.glp** - Simple case that WORKS
- **test_conj_var.glp** - Nested case that FAILS

## Critical Code Sections

### Compiler: Line 676-683 in codegen.dart
```dart
} else if (term is StructTerm) {
  // Nested structure - build recursively
  ctx.emit(bc.PutStructure(term.functor, term.arity, -1)); // -1 = nested

  for (final arg in term.args) {
    _generateStructureElementInBody(arg, varTable, ctx); // Recursive!
  }
}
```
✅ This compiles successfully

### Runtime: Lines 1514-1544 in runner.dart
```dart
if (op is PutStructure) {
  if (cx.inBody) {
    // Creates fresh writer/reader pair
    // Stores in cx.clauseVars[-1] as marker
    // Sets cx.currentStructure = StructTerm(...)
    // Problem: What if we're already building a structure?
  }
}
```
❌ No handling for nested structure building

### Runtime: Lines 1547-1598 in runner.dart
```dart
if (op is SetWriter) {
  // Checks cx.clauseVars[op.varIndex] for existing writer ✅
  // Adds to cx.currentStructure.args[cx.S] ✅
  // Increments cx.S ✅
  // When complete (cx.S >= arity), binds structure ✅
}
```
✅ This works for single-level structures

## Design Questions

### 1. Structure Building Stack
Should we add to ExecutionContext:
```dart
class StructBuildContext {
  StructTerm structure;
  int position;  // S register
  int targetWriter;  // Writer to bind when complete
}

List<StructBuildContext> structStack = [];
```

### 2. PutStructure with argSlot == -1
How should runtime handle this?
- Option A: Push current structure onto stack, start new one
- Option B: Pre-build nested structure in temp, add as constant
- Option C: Something else?

### 3. Variable Sharing Across Nesting
In `(merge([],[],Xs1), merge([],Xs1?,Ys))`:
- `Xs1` appears in BOTH nested structures
- Writer allocated once, reader used twice
- How does stack preserve this sharing?

### 4. Completion Detection
How does runtime know when nested structure is complete?
- Track S vs arity?
- Implicit from instruction sequence?
- Need end-of-structure marker?

## Expected Behavior

**Test:** `test_conj(Y?) :- foo((bar(X), baz(X?,Y)))`
**Fact:** `foo((bar(a), baz(a,b)))`
**Expected:** `Y = b`
**Actual:** `Y = <unbound>`

**Test:** `run2(Ys?) :- run((merge([],[],Xs1), merge([],Xs1?,Ys)))`
**Expected:** `Ys = []` (two merges with shared variable)
**Actual:** `Ys = <unbound>`

## GLP Architecture Notes

- **SRSW Dataflow:** Each variable has one Writer, one Reader
- **WAM-style:** Structure building follows Warren Abstract Machine patterns
- **Committed-choice:** Non-backtracking, parallel goal execution
- **HeapV2:** Writer/Reader cells for dataflow unification

## Request for Claude Web

Please analyze the architecture and recommend:
1. Best approach for nested structure building (stack vs pre-build)
2. How to handle variable sharing across nested contexts
3. Specific code changes needed in runner.dart
4. Testing strategy to verify correctness

The goal is to make `run2(X)` and `test_conj(Z)` work while preserving the 90% that already works.

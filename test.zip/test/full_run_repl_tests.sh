#!/bin/bash
# GLP REPL Full Test Suite - FAST VERSION (~3-5s)
# Loads all files in single REPL session for speed
# NOTE: arithmetic_fixed.glp excluded (conflicts with primes.glp mod guards)
# NOTE: SRSW violation tests run separately at end

set -e

DART=${DART:-$(which dart 2>/dev/null || echo "/home/user/dart-sdk/bin/dart")}
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
GLP_RUNTIME="$SCRIPT_DIR/../glp_runtime"
GLP_DIR="$SCRIPT_DIR/../programs/tests/repl"
MOD_DIR="$SCRIPT_DIR/../programs/tests/modules"
REPL="bin/glp_repl.dart"

cd "$GLP_RUNTIME"

echo "======================================"
echo "   GLP REPL Full Test Suite (FAST)   "
echo "======================================"
echo ""

# Load all files and run all queries in single session
output=$($DART run "$REPL" <<REPL_INPUT
$GLP_DIR/hello.glp
$GLP_DIR/p.glp
$GLP_DIR/merge.glp
$GLP_DIR/merge_standalone.glp
$GLP_DIR/run1.glp
$GLP_DIR/append.glp
$GLP_DIR/reverse.glp
$GLP_DIR/copy.glp
$GLP_DIR/opmerge.glp
$GLP_DIR/fsmerge.glp
$GLP_DIR/gates.glp
$GLP_DIR/qsort.glp
$GLP_DIR/isort.glp
$GLP_DIR/bsort.glp
$GLP_DIR/struct_demo.glp
$GLP_DIR/sum_direct.glp
$GLP_DIR/ip_direct.glp
$GLP_DIR/multiply_direct.glp
$GLP_DIR/fib_direct.glp
$GLP_DIR/hanoi.glp
$GLP_DIR/sum_list.glp
$GLP_DIR/inner_product.glp
$GLP_DIR/multiply.glp
$GLP_DIR/fib.glp
$GLP_DIR/factorial.glp
$GLP_DIR/test_time.glp
$GLP_DIR/primes.glp
$GLP_DIR/no_guard.glp
$GLP_DIR/with_guard.glp
$GLP_DIR/bb_diff.glp
$GLP_DIR/nonground_list.glp
$GLP_DIR/reader_output.glp
$GLP_DIR/two_struct_list.glp
$GLP_DIR/depth_test.glp
$GLP_DIR/paa.glp
$GLP_DIR/test_bob.glp
$GLP_DIR/test_nested_suspend.glp
$GLP_DIR/test_defined_guards.glp
$GLP_DIR/append_dl.glp
$GLP_DIR/assign_reader_test.glp
hello.
p(X).
merge([1,2,3], [a,b], Xs).
merge([1,2], [a,b], Xs2).
clause(p(a), B).
run(true).
run(merge([a,b],[b],X)).
run_isort(insertion_sort([3,4,2,3,6,1,2],Xsort)).
append([a,b], [c,d], Zs).
append([], [x,y], Zs2).
append([a,b], [], Zs3).
reverse([a,b,c], Ys).
reverse([], Ys2).
reverse([x], Ys3).
copy([a,b,c], Yc).
copy([], Yc2).
opmerge([1,3,5], [2,4,6], Zop).
opmerge([1,2,3], [2,3,4], Zop2).
opmerge([], [1,2], Zop3).
fsmerge([a,b,c], [x,y,z], Zfs).
fsmerge([a,b], [x,y,z], Zfs2).
and([one,zero,one], [one,one,zero], OutA).
or([one,zero,one], [one,one,zero], OutO).
and([one,one], [one,one], OutA2).
or([zero,zero], [zero,zero], OutO2).
quicksort([],Xq1).
quicksort([1],Xq2).
quicksort([1,2],Xq3).
quicksort([1,6,4,2,7,4,2,6],Xq4).
quicksort([1,3,4,2,5],Xq5).
quicksort([a],Xq6).
quicksort([1|X?],Xq7).
insertion_sort([],Xi1).
insertion_sort([3],Xi2).
insertion_sort([3,4],Xi3).
sort([3,1,4,1,5], Ybs).
sort([], Ybs2).
sort([7], Ybs3).
build_person(P).
run(merge([a],[b],Xm1)).
run(merge([a],[b,c,d],Xm2)).
run2(Xr2).
run((merge([a],[b],Xc),merge(Xc?,[c],Yc))).
run_qsort(quicksort([],Xrq1)).
run_qsort(quicksort([1],Xrq2)).
run1_qsort(run_qsort(quicksort([1],Xrq3))).
run1_qsort(run_qsort(quicksort([1,4,3,2,4,5],Xrq4))).
sumd([1,2,3,4,5], Sd1).
sumd([], Sd2).
ipd([1,2,3], [4,5,6], Sip1).
ipd([2], [3], Sip2).
multiplyd(3, [1,2,3,4], Ym1).
multiplyd(5, [], Ym2).
fibd(0, Fd0).
fibd(1, Fd1).
fibd(2, Fd2).
hanoi(0, a, c, Mh0).
hanoi(1, a, c, Mh1).
hanoi(2, a, c, Mh2).
sum([1,2,3,4,5], Ssl1).
ip([1,2,3], [4,5,6], Sipf).
multiply(3, [1,2,3,4], Ymf).
fib(0, Ff0).
fib(1, Ff1).
factorial(1, Fac1).
factorial(2, Fac2).
fib(3, Ff3).
fib(10, Ff10).
factorial(3, Fac3).
factorial(5, Fac5).
run_fact(factorial(5, Facm)).
run_mult(multiply(3, [1,2,3,4], Ymm)).
run_sum(sum([1,2,3,4,5], Ssm)).
run_ip(ip([1,2,3], [4,5,6], Sipm)).
run_hanoi(hanoi(2, a, c, Mhm)).
T1 =.. [foo].
T2 =.. [bar, x, y].
foo(a, b) =.. L1.
bar(1, 2, 3) =.. L2.
Xu1 = foo.
Xu2 = 42.
Xu3 = foo(a, b).
Xu4 = [1, 2, 3].
Xu5 = foo(bar(a)).
Xu6 = Y?.
Xa1 := 3.
Xa2 := 5 + 3.
Xa3 := 10 - 4.
Xa4 := 4 * 7.
Xa5 := 20 / 4.
Xa6 := 5 + 3 * 2.
Xa7 := (5 + 3) * 2.
Xa8 := -5.
time_advances(Tadv).
past_time(1000000000000, Xpast).
past_time(9999999999999, Xfuture).
wait_test(Xwait).
primes(20, Ps20).
primes(10, Ps10).
no_guard(Xng, 5).
with_guard(Xwg, 5).
Xsl = [send(1,a), send(2,b)].
open(1, Xopen, Yopen).
open2(1, Xopen2).
append([1,2|T1?], T1, [3,4|T2?], T2, Hdl, Tdl?).
test_list_in_body([1,2,3,4], Xngl).
build_list(a, b, Xbld).
unwrap([hello], Xunw).
identity(foo, Xid).
test(Xtsl).
bin_nest(Xbn, val).
ter_all(Xta, a, b, c).
tree3(Xtr3, val).
multi_w(Xmw, p, q).
p(Xpaa1, Xpaa1?).
p(Xpaa2?, Xpaa2).
bob(Xbob?).
level1(Xlv1?).
level2([Xlv2?|Rlv2]).
level3([wrapper(Xlv3?)|Rlv3]).
# Defined guards via partial evaluation
test(ch(Adg?, Bdg), Rdg1).
test(foo, Rdg2).
test(Xdg?, Rdg3).
assign_reader(Rar?, Xar).
# Channel operations as defined guards
$GLP_DIR/test_channel_guards.glp
make_pair(ch(Achg?, Bchg), Rchg).
# Comprehensive defined guards test suite
$GLP_DIR/test_defined_guards_all.glp
make_pair(Call1, Call2).
bind_response(yes, RespYes, LocalYes).
bind_response(no, RespNo, LocalNo).
test_channel(ch(TchA?, TchB), TchR1).
test_channel(foo, TchR2).
test_channel(p(TpaA, TpaB), TchR3).
test_pair(p(TprA, TprB), TprR1).
test_pair(foo, TprR2).
test_wrapper(w(TwrX), TwrR1).
test_wrapper(foo, TwrR2).
test_nested(w(p(TnA, TnB)), TnR1).
test_nested(w(hello), TnR2).
test_nested(foo, TnR3).
test_wrap(hello, TwpR).
test_deep(foo, TdpR).
test_triple(1, 2, TtrR).
relay_send([], RsOut, ch([], [])).
relay_recv([], RrOut, ch([], [])).
relay([], RelayOut, ch([], [])).
switch2x2(ch([], SwA), ch([], SwB), ch(SwC, []), ch(SwD, [])).
:quit
REPL_INPUT
2>&1)

# Test definitions: "Name:pattern"
declare -a tests=(
    # Basic tests
    "Hello World:Hello from GLP!"
    "Simple Unification:X = a"

    # Merge tests
    "Merge [1,2,3] and [a,b]:Xs = \[1, a, 2, b, 3\]"
    "Merge standalone:Xs2 = \[1, a, 2, b\]"

    # Metainterpreter tests
    "Clause Lookup:B = true"
    "Simple Run:run(true)"
    "Merge via Metainterpreter:X = \[a, b, b\]"
    "Insertion Sort via Meta:Xsort = \[1, 2, 2, 3, 3, 4, 6\]"

    # List operations
    "Append two lists:Zs = \[a, b, c, d\]"
    "Append empty list:Zs2 = \[x, y\]"
    "Append to empty list:Zs3 = \[a, b\]"
    "Reverse list:Ys = \[c, b, a\]"
    "Reverse empty list:Ys2 = \[\]"
    "Reverse single element:Ys3 = \[x\]"
    "Copy list:Yc = \[a, b, c\]"
    "Copy empty list:Yc2 = \[\]"
    "Ordered merge:Zop = \[1, 2, 3, 4, 5, 6\]"
    "Ordered merge duplicates:Zop2 = \[1, 2, 3, 4\]"
    "Ordered merge empty:Zop3 = \[1, 2\]"
    "Fair stable merge:Zfs = \[a, x, b, y, c, z\]"
    "Fair stable merge unequal:Zfs2 = \[a, x, b, y, z\]"

    # Logic gates
    "AND gate:OutA = \[one, zero, zero\]"
    "OR gate:OutO = \[one, one, one\]"
    "AND gate all ones:OutA2 = \[one, one\]"
    "OR gate all zeros:OutO2 = \[zero, zero\]"

    # Quicksort
    "Quicksort empty:Xq1 = \[\]"
    "Quicksort single:Xq2 = \[1\]"
    "Quicksort two:Xq3 = \[1, 2\]"
    "Quicksort larger:Xq4 = \[1, 2, 2, 4, 4, 6, 6, 7\]"
    "Quicksort five:Xq5 = \[1, 2, 3, 4, 5\]"
    "Quicksort non-number:Xq6 = <unbound>"
    "Quicksort unbound tail:Xq7 = <unbound>"

    # Insertion sort
    "Insertion sort empty:Xi1 = \[\]"
    "Insertion sort single:Xi2 = \[3\]"
    "Insertion sort two:Xi3 = \[3, 4\]"

    # Bubble sort
    "Bubble sort:Ybs = \[1, 1, 3, 4, 5\]"
    "Bubble sort empty:Ybs2 = \[\]"
    "Bubble sort single:Ybs3 = \[7\]"

    # Structure demo
    "Structure Demo:P = person"

    # Meta merge tests
    "Meta merge [a],[b]:Xm1 = \[a, b\]"
    "Meta merge [a],[b,c,d]:Xm2 = \[a, b, c, d\]"
    "Meta run2:→ succeeds"
    "Meta merge chain:Yc = \[a, c, b\]"

    # Meta quicksort
    "Meta quicksort empty:Xrq1 = \[\]"
    "Meta quicksort single:Xrq2 = \[1\]"
    "Nested meta quicksort 1:Xrq3 = \[1\]"
    "Nested meta quicksort 6:Xrq4 = \[1, 2, 3, 4, 4, 5\]"

    # Arithmetic direct
    "Sum list direct:Sd1 = 15"
    "Sum empty direct:Sd2 = 0"
    "Inner product direct:Sip1 = 32"
    "Inner product single:Sip2 = 6"
    "Multiply stream:Ym1 = \[3, 6, 9, 12\]"
    "Multiply stream empty:Ym2 = \[\]"
    "Fibonacci 0 direct:Fd0 = 0"
    "Fibonacci 1 direct:Fd1 = 1"
    "Fibonacci 2 direct:Fd2 = 1"

    # Hanoi
    "Hanoi 0:→ succeeds"
    "Hanoi 1:→ succeeds"
    "Hanoi 2:→ succeeds"

    # Full arithmetic files
    "Sum list full:Ssl1 = 15"
    "Inner product full:Sipf = 32"
    "Multiply stream full:Ymf = \[3, 6, 9, 12\]"
    "Fibonacci 0 full:Ff0 = 0"
    "Fibonacci 1 full:Ff1 = 1"
    "Factorial 1:Fac1 = 1"
    "Factorial 2:Fac2 = 2"

    # Non-tail-recursive
    "Fibonacci 3:Ff3 = 2"
    "Fibonacci 10:Ff10 = 55"
    "Factorial 3:Fac3 = 6"
    "Factorial 5:Fac5 = 120"

    # Meta + arithmetic
    "Meta factorial 5:Facm = 120"
    "Meta multiply:Ymm = \[3, 6, 9, 12\]"
    "Meta sum:Ssm = 15"
    "Meta inner product:Sipm = 32"
    "Meta hanoi 2:→ succeeds"

    # Univ
    "Univ compose [foo]:T1 = foo()"
    "Univ compose [bar,x,y]:T2 = bar(x, y)"
    "Univ decompose foo(a,b):L1 = \[foo, a, b\]"
    "Univ decompose bar(1,2,3):L2 = \[bar, 1, 2, 3\]"

    # Unification
    "Unify atom:Xu1 = foo"
    "Unify number:Xu2 = 42"
    "Unify structure:Xu3 = foo(a, b)"
    "Unify list:Xu4 = \[1, 2, 3\]"
    "Unify nested:Xu5 = foo(bar(a))"
    "Unify suspend:suspended"

    # Assignment
    "Assign plain:Xa1 = 3"
    "Assign add:Xa2 = 8"
    "Assign sub:Xa3 = 6"
    "Assign mul:Xa4 = 28"
    "Assign div:Xa5 = 5"
    "Assign precedence:Xa6 = 11"
    "Assign parens:Xa7 = 16"
    "Assign negative:Xa8 = -5"

    # Time predicates
    "Time advances:Tadv = true"
    "Time past:Xpast = yes"
    "Time future:failed"
    "Time wait:Xwait = done"

    # Primes
    "Primes 20:Ps20 = \[2, 3, 5, 7, 11, 13, 17, 19\]"
    "Primes 10:Ps10 = \[2, 3, 5, 7\]"

    # Guard tests (sigmaHat fix)
    "Guard - no guard:Xng = \[5, a, b\]"
    "Guard - with guard:Xwg = \[5, a, b\]"

    # Structs in list
    "Structs in list:Xsl = \[send(1, a), send(2, b)\]"
    "Two structs in list:Xtsl = \[foo(a), bar(b)\]"

    # Nested structures with vars (depth test)
    "Nested binary with var:Xbn = outer(inner(val, b), c)"
    "Ternary all vars:Xta = triple(a, b, c)"
    "Deep binary tree:Xtr3 = node(node(leaf(val), leaf(a)), leaf(b))"
    "Multiple writers nested:Xmw = pair(wrap(p), wrap(q))"

    # Bounded buffer - WxW: goal unbound writer vs head writer fails
    # (open/3 uses incorrect mode annotations - T should be T?)
    "Open buffer:failed"

    # Open2 - WxW-compliant version with single dl(Head,Tail) output
    "Open2 buffer:Xopen2 = dl"

    # Difference list append (now correctly unifies T1 with T1?)
    "DL append:Hdl = \[1, 2, 3, 4 |"

    # Non-ground list in body (codegen fix)
    "Non-ground list pass:Xngl = \[1, 2, 3, 4\]"
    "Non-ground list build:Xbld = \[a, b\]"

    # Reader in output position (runtime fix)
    "Unwrap list element:Xunw = hello"
    "Identity returns value:Xid = foo"

    # Two-phase HEAD unification (writer/reader same variable)
    "p(X,X?) succeeds:Xpaa1 = a"
    "p(X?,X) succeeds:→ succeeds"

    # Suspension tests (unbound reader vs structure pattern)
    "Suspend bob(X?) unbound:bob(X.*) → suspended"
    "Suspend level1(X?) unbound:level1(X.*) → suspended"
    "Suspend level2 nested:level2(.*) → suspended"
    "Suspend level3 deep nested:level3(.*) → suspended"

    # Defined guards via partial evaluation
    "Defined guard match:Rdg1 = ok"
    "Defined guard fail:Rdg2 = not_channel"
    "Defined guard suspend:test(X.*, Rdg3) → suspended"

    # Channel operations as defined guards
    "Channel make_pair:Rchg = ch("

    # Comprehensive defined guards test suite
    "DG make_pair creates channels:Call1 = ch("
    "DG bind_response yes:RespYes = accept(ch("
    "DG bind_response yes local:LocalYes = ch("
    "DG bind_response no:RespNo = no"
    "DG bind_response no local:LocalNo = none"
    "DG channel test success:TchR1 = ok"
    "DG channel test fail atom:TchR2 = not_channel"
    "DG channel test fail pair:TchR3 = not_channel"
    "DG pair test success:TprR1 = ok"
    "DG pair test fail:TprR2 = not_pair"
    "DG wrapper test success:TwrR1 = ok"
    "DG wrapper test fail:TwrR2 = not_wrapper"
    "DG nested wrapper with pair:TnR1 = wrapper_with_pair"
    "DG nested just wrapper:TnR2 = just_wrapper"
    "DG nested neither:TnR3 = neither"
    "DG wrap binding:TwpR = wrapped(hello)"
    "DG deep binding:TdpR = outer(inner(foo))"
    "DG triple binding:TtrR = pair(1, 2)"
    "DG relay_send base:RsOut = \[\]"
    "DG relay_recv base:RrOut = \[\]"
    "DG relay base:RelayOut = \[\]"
    "DG switch2x2 base:switch2x2(.*) :- true"

    # Goal reader vs head writer (should succeed, not suspend)
    "Goal reader to head writer:assign_reader(.*) :- true"
)

PASS=0
FAIL=0

for test in "${tests[@]}"; do
    name="${test%%:*}"
    pattern="${test#*:}"
    if echo "$output" | grep -q "$pattern"; then
        echo "PASS: $name"
        PASS=$((PASS + 1))
    else
        echo "FAIL: $name (expected: $pattern)"
        FAIL=$((FAIL + 1))
    fi
done

# Run SRSW violation test separately
echo ""
echo "--- SRSW Violation Tests ---"

srsw_output=$($DART run "$REPL" <<SRSW_INPUT
$GLP_DIR/merge_with_reader.glp
:quit
SRSW_INPUT
2>&1)

if echo "$srsw_output" | grep -q "SRSW violation"; then
    echo "PASS: SRSW Check - merge_with_reader.glp rejected"
    PASS=$((PASS + 1))
else
    echo "FAIL: SRSW Check - merge_with_reader.glp should be rejected"
    FAIL=$((FAIL + 1))
fi

# Run arithmetic_fixed.glp tests separately (conflicts with primes)
echo ""
echo "--- Arithmetic Fixed Tests (separate session) ---"

arith_output=$($DART run "$REPL" <<ARITH_INPUT
$GLP_DIR/arithmetic_fixed.glp
add(5, 3, Xadd).
multiply(4, 7, Ymul).
compute(Zcomp).
:quit
ARITH_INPUT
2>&1)

if echo "$arith_output" | grep -q "Xadd = 8"; then
    echo "PASS: Addition 5+3"
    PASS=$((PASS + 1))
else
    echo "FAIL: Addition 5+3 (expected: Xadd = 8)"
    FAIL=$((FAIL + 1))
fi

if echo "$arith_output" | grep -q "Ymul = 28"; then
    echo "PASS: Multiplication 4*7"
    PASS=$((PASS + 1))
else
    echo "FAIL: Multiplication 4*7 (expected: Ymul = 28)"
    FAIL=$((FAIL + 1))
fi

if echo "$arith_output" | grep -q "Zcomp = 10"; then
    echo "PASS: Compound (2*3)+4"
    PASS=$((PASS + 1))
else
    echo "FAIL: Compound (2*3)+4 (expected: Zcomp = 10)"
    FAIL=$((FAIL + 1))
fi

# Run mwm tests (MutualRef multiway merge)
echo ""
echo "--- MWM (Multiway Merge) Tests ---"

mwm_output=$($DART run "$REPL" <<MWM_INPUT
mwm([], Xmwm1).
mwm([stream([1,2,3])], Xmwm2).
mwm([stream([a,b]), stream([1,2])], Xmwm3).
:quit
MWM_INPUT
2>&1)

if echo "$mwm_output" | grep -q "Xmwm1 = \[\]"; then
    echo "PASS: MWM empty"
    PASS=$((PASS + 1))
else
    echo "FAIL: MWM empty (expected: Xmwm1 = [])"
    FAIL=$((FAIL + 1))
fi

if echo "$mwm_output" | grep -q "Xmwm2 = \[1, 2, 3\]"; then
    echo "PASS: MWM single stream"
    PASS=$((PASS + 1))
else
    echo "FAIL: MWM single stream (expected: Xmwm2 = [1, 2, 3])"
    FAIL=$((FAIL + 1))
fi

if echo "$mwm_output" | grep -q "Xmwm3 = \[a, b, 1, 2\]"; then
    echo "PASS: MWM two streams"
    PASS=$((PASS + 1))
else
    echo "FAIL: MWM two streams (expected: Xmwm3 = [a, b, 1, 2])"
    FAIL=$((FAIL + 1))
fi

# Run ground equality (=?=) tests
echo ""
echo "--- Ground Equality (=?=) Guard Tests ---"

ge_output=$($DART run "$REPL" <<GE_INPUT
$GLP_DIR/test_ground_equal.glp
test(a, a, R1).
test(a, b, R2).
test(foo(1,2), foo(1,2), R3).
test(foo(1,2), foo(1,3), R4).
test([1,2,3], [1,2,3], R5).
test([1,2], [1,3], R6).
:quit
GE_INPUT
2>&1)

if echo "$ge_output" | grep -q "R1 = equal"; then
    echo "PASS: =?= atoms equal"
    PASS=$((PASS + 1))
else
    echo "FAIL: =?= atoms equal (expected: R1 = equal)"
    FAIL=$((FAIL + 1))
fi

if echo "$ge_output" | grep -q "R2 = not_equal"; then
    echo "PASS: =?= atoms not equal"
    PASS=$((PASS + 1))
else
    echo "FAIL: =?= atoms not equal (expected: R2 = not_equal)"
    FAIL=$((FAIL + 1))
fi

if echo "$ge_output" | grep -q "R3 = equal"; then
    echo "PASS: =?= structures equal"
    PASS=$((PASS + 1))
else
    echo "FAIL: =?= structures equal (expected: R3 = equal)"
    FAIL=$((FAIL + 1))
fi

if echo "$ge_output" | grep -q "R4 = not_equal"; then
    echo "PASS: =?= structures not equal"
    PASS=$((PASS + 1))
else
    echo "FAIL: =?= structures not equal (expected: R4 = not_equal)"
    FAIL=$((FAIL + 1))
fi

if echo "$ge_output" | grep -q "R5 = equal"; then
    echo "PASS: =?= lists equal"
    PASS=$((PASS + 1))
else
    echo "FAIL: =?= lists equal (expected: R5 = equal)"
    FAIL=$((FAIL + 1))
fi

if echo "$ge_output" | grep -q "R6 = not_equal"; then
    echo "PASS: =?= lists not equal"
    PASS=$((PASS + 1))
else
    echo "FAIL: =?= lists not equal (expected: R6 = not_equal)"
    FAIL=$((FAIL + 1))
fi

# --- Guard Negation (~G) Tests ---
echo ""
echo "--- Guard Negation (~G) Tests ---"

gn_output=$(echo -e "$GLP_DIR/test_guard_negation.glp\ntest_neg_int(5, R1).\ntest_neg_int(hello, R2).\ntest_neg_number(3.14, R3).\ntest_neg_number(hello, R4).\ntest_neg_eq(5, 5, R5).\ntest_neg_eq(5, 3, R6)." | $DART run $REPL 2>&1)

if echo "$gn_output" | grep -q "R1 = is_int"; then
    echo "PASS: ~integer(5) fails, integer succeeds"
    PASS=$((PASS + 1))
else
    echo "FAIL: ~integer(5) fails, integer succeeds (expected: R1 = is_int)"
    FAIL=$((FAIL + 1))
fi

if echo "$gn_output" | grep -q "R2 = not_int"; then
    echo "PASS: ~integer(hello) succeeds"
    PASS=$((PASS + 1))
else
    echo "FAIL: ~integer(hello) succeeds (expected: R2 = not_int)"
    FAIL=$((FAIL + 1))
fi

if echo "$gn_output" | grep -q "R3 = is_num"; then
    echo "PASS: ~number(3.14) fails, number succeeds"
    PASS=$((PASS + 1))
else
    echo "FAIL: ~number(3.14) fails, number succeeds (expected: R3 = is_num)"
    FAIL=$((FAIL + 1))
fi

if echo "$gn_output" | grep -q "R4 = not_num"; then
    echo "PASS: ~number(hello) succeeds"
    PASS=$((PASS + 1))
else
    echo "FAIL: ~number(hello) succeeds (expected: R4 = not_num)"
    FAIL=$((FAIL + 1))
fi

if echo "$gn_output" | grep -q "R5 = eq"; then
    echo "PASS: ~(5 =?= 5) fails, equality succeeds"
    PASS=$((PASS + 1))
else
    echo "FAIL: ~(5 =?= 5) fails, equality succeeds (expected: R5 = eq)"
    FAIL=$((FAIL + 1))
fi

if echo "$gn_output" | grep -q "R6 = neq"; then
    echo "PASS: ~(5 =?= 3) succeeds"
    PASS=$((PASS + 1))
else
    echo "FAIL: ~(5 =?= 3) succeeds (expected: R6 = neq)"
    FAIL=$((FAIL + 1))
fi

# --- Invalid Guard Tests ---
echo ""
echo "--- Invalid Guard Tests ---"

# Create temp file with true in guard position
TMP_TRUE_GUARD=$(mktemp --suffix=.glp)
echo 'bad_guard(X?) :- true | X = done.' > "$TMP_TRUE_GUARD"

true_guard_output=$($DART run "$REPL" <<TRUE_INPUT
$TMP_TRUE_GUARD
:quit
TRUE_INPUT
2>&1)

rm -f "$TMP_TRUE_GUARD"

if echo "$true_guard_output" | grep -q '"true" is not a guard'; then
    echo "PASS: true in guard position rejected"
    PASS=$((PASS + 1))
else
    echo "FAIL: true in guard position should be rejected"
    FAIL=$((FAIL + 1))
fi

# --- Module RPC Tests ---
echo ""
echo "--- Module RPC Tests ---"

module_output=$($DART run "$REPL" <<MODULE_INPUT
$GLP_DIR/mod_a.glp
$GLP_DIR/main_mod.glp
test(R).
:quit
MODULE_INPUT
2>&1)

if echo "$module_output" | grep -q "R = 10"; then
    echo "PASS: Cross-module RPC: mod_a # double(5, R) returns R = 10"
    PASS=$((PASS + 1))
else
    echo "FAIL: Cross-module RPC: mod_a # double(5, R) (expected: R = 10)"
    FAIL=$((FAIL + 1))
fi

if echo "$module_output" | grep -q "→ succeeds"; then
    echo "PASS: Cross-module RPC succeeds"
    PASS=$((PASS + 1))
else
    echo "FAIL: Cross-module RPC should succeed"
    FAIL=$((FAIL + 1))
fi

# Test 2: Recursive RPC - math#factorial
factorial_output=$($DART run "$REPL" <<FACTORIAL_INPUT
$MOD_DIR/math.glp
$MOD_DIR/main.glp
test_factorial(R).
:quit
FACTORIAL_INPUT
2>&1)

if echo "$factorial_output" | grep -q "R = 120"; then
    echo "PASS: Recursive RPC: math#factorial(5) returns R = 120"
    PASS=$((PASS + 1))
else
    echo "FAIL: Recursive RPC: math#factorial(5) (expected: R = 120)"
    FAIL=$((FAIL + 1))
fi

# Test 3: Chain RPC - A→B→C
chain_output=$($DART run "$REPL" <<CHAIN_INPUT
$MOD_DIR/utils.glp
$MOD_DIR/chain_b.glp
$MOD_DIR/chain_a.glp
run(4, R).
:quit
CHAIN_INPUT
2>&1)

if echo "$chain_output" | grep -q "R = 12"; then
    echo "PASS: Chain RPC: A→B→C (4*3=12)"
    PASS=$((PASS + 1))
else
    echo "FAIL: Chain RPC: A→B→C (expected: R = 12)"
    FAIL=$((FAIL + 1))
fi

# Test 4: Missing module - RPC suspends
missing_output=$($DART run "$REPL" <<MISSING_INPUT
$MOD_DIR/main.glp
test_double(R).
:quit
MISSING_INPUT
2>&1)

if echo "$missing_output" | grep -q "suspended"; then
    echo "PASS: Missing module: RPC suspends"
    PASS=$((PASS + 1))
else
    echo "FAIL: Missing module should suspend (got: $missing_output)"
    FAIL=$((FAIL + 1))
fi

# Test 5: Unexported procedure - error
unexported_output=$($DART run "$REPL" <<UNEXPORTED_INPUT
$MOD_DIR/math.glp
math # private_helper(X).
:quit
UNEXPORTED_INPUT
2>&1)

if echo "$unexported_output" | grep -qE "unknown|not exported|error|Error|not found"; then
    echo "PASS: Unexported procedure rejected"
    PASS=$((PASS + 1))
else
    echo "FAIL: Unexported procedure should be rejected"
    FAIL=$((FAIL + 1))
fi

# Test 6: Backwards compatibility - no module declaration
compat_output=$($DART run "$REPL" <<COMPAT_INPUT
$GLP_DIR/factorial.glp
factorial(5, R).
:quit
COMPAT_INPUT
2>&1)

if echo "$compat_output" | grep -q "R = 120"; then
    echo "PASS: Backwards compat: no module decl works"
    PASS=$((PASS + 1))
else
    echo "FAIL: Backwards compat: factorial(5) should return 120"
    FAIL=$((FAIL + 1))
fi

# Test 7: Dynamic RPC - module as variable
dynamic_output=$($DART run "$REPL" <<DYNAMIC_INPUT
$MOD_DIR/math.glp
M = math, M? # double(7, R).
:quit
DYNAMIC_INPUT
2>&1)

if echo "$dynamic_output" | grep -q "R = 14"; then
    echo "PASS: Dynamic RPC: M? # double(7, R) returns R = 14"
    PASS=$((PASS + 1))
else
    echo "FAIL: Dynamic RPC: M? # double(7, R) (expected: R = 14)"
    FAIL=$((FAIL + 1))
fi

# --- Auto-generated reduce/2 Tests ---
echo ""
echo "--- Auto-generated reduce/2 Tests ---"

# Test 8: reduce/2 for fact
reduce_fact_output=$($DART run "$REPL" <<REDUCE_FACT
$GLP_DIR/reduce_test.glp
reduce(hello(world), Body).
:quit
REDUCE_FACT
2>&1)

if echo "$reduce_fact_output" | grep -q "Body = true"; then
    echo "PASS: reduce/2 for fact: hello(world) -> true"
    PASS=$((PASS + 1))
else
    echo "FAIL: reduce/2 for fact (expected: Body = true)"
    FAIL=$((FAIL + 1))
fi

# Test 9: reduce/2 for rule without guard
reduce_rule_output=$($DART run "$REPL" <<REDUCE_RULE
$GLP_DIR/reduce_test.glp
reduce(greet(foo, Y), Body).
:quit
REDUCE_RULE
2>&1)

if echo "$reduce_rule_output" | grep -qE "Body = :="; then
    echo "PASS: reduce/2 for rule: greet(foo, Y) -> Body contains :="
    PASS=$((PASS + 1))
else
    echo "FAIL: reduce/2 for rule (expected: Body contains :=)"
    FAIL=$((FAIL + 1))
fi

# Test 10: reduce/2 for guarded rule
reduce_guarded_output=$($DART run "$REPL" <<REDUCE_GUARDED
$GLP_DIR/reduce_test.glp
reduce(double(5, Y), Body).
:quit
REDUCE_GUARDED
2>&1)

if echo "$reduce_guarded_output" | grep -qE "Body = :=.*\*.*5.*2"; then
    echo "PASS: reduce/2 for guarded rule: double(5, Y) -> Body contains 5*2"
    PASS=$((PASS + 1))
else
    echo "FAIL: reduce/2 for guarded rule (expected: Body contains multiplication)"
    FAIL=$((FAIL + 1))
fi

# --- Quoted Atom Functor Tests ---
echo ""
echo "--- Quoted Atom Functor Tests ---"

# Test: Quoted atom as functor in head
quoted_head_output=$($DART run "$REPL" <<QUOTED_HEAD
$GLP_DIR/quoted_functor_test.glp
'_test_kernel'(5, R).
:quit
QUOTED_HEAD
2>&1)

if echo "$quoted_head_output" | grep -q "R = 6"; then
    echo "PASS: Quoted atom functor in head: '_test_kernel'(5, R) returns R = 6"
    PASS=$((PASS + 1))
else
    echo "FAIL: Quoted atom functor in head (expected: R = 6)"
    FAIL=$((FAIL + 1))
fi

# Test: Quoted atom as functor in body
quoted_body_output=$($DART run "$REPL" <<QUOTED_BODY
$GLP_DIR/quoted_functor_test.glp
$GLP_DIR/quoted_body_test.glp
wrapper(10, R).
:quit
QUOTED_BODY
2>&1)

if echo "$quoted_body_output" | grep -q "R = 11"; then
    echo "PASS: Quoted atom functor in body: wrapper(10, R) returns R = 11"
    PASS=$((PASS + 1))
else
    echo "FAIL: Quoted atom functor in body (expected: R = 11)"
    FAIL=$((FAIL + 1))
fi

# Test: Quoted atom as structure functor
quoted_struct_output=$($DART run "$REPL" <<QUOTED_STRUCT
X = '_equator'(E, stop).
:quit
QUOTED_STRUCT
2>&1)

if echo "$quoted_struct_output" | grep -q "_equator"; then
    echo "PASS: Quoted atom as structure functor: X = '_equator'(E, stop)"
    PASS=$((PASS + 1))
else
    echo "FAIL: Quoted atom as structure functor"
    FAIL=$((FAIL + 1))
fi

# --- Circular Term Tests ---
# Tests for circular term creation and helper predicates
echo ""
echo "--- Circular Term Tests ---"

circular_output=$($DART run "$REPL" <<CIRCULAR_INPUT
$GLP_DIR/circular_test.glp
link(A, f(B?)), link(B, f(A?)).
is_ground(foo, R1).
is_ground(f(a,b), R2).
test_equal(foo, foo, R3).
test_equal(foo, bar, R4).
test_self_equal(f(a,b), R5).
show(hello, X).
:quit
CIRCULAR_INPUT
2>&1)

# Test circular term creation and display
if echo "$circular_output" | grep -q "<circular>"; then
    echo "PASS: Circular term created and displayed with <circular> marker"
    PASS=$((PASS + 1))
else
    echo "FAIL: Circular term creation (expected: <circular> marker in output)"
    FAIL=$((FAIL + 1))
fi

if echo "$circular_output" | grep -q "R1 = yes"; then
    echo "PASS: is_ground(foo) = yes"
    PASS=$((PASS + 1))
else
    echo "FAIL: is_ground(foo) (expected: R1 = yes)"
    FAIL=$((FAIL + 1))
fi

if echo "$circular_output" | grep -q "R2 = yes"; then
    echo "PASS: is_ground(f(a,b)) = yes"
    PASS=$((PASS + 1))
else
    echo "FAIL: is_ground(f(a,b)) (expected: R2 = yes)"
    FAIL=$((FAIL + 1))
fi

if echo "$circular_output" | grep -q "R3 = yes"; then
    echo "PASS: test_equal(foo,foo) = yes"
    PASS=$((PASS + 1))
else
    echo "FAIL: test_equal(foo,foo) (expected: R3 = yes)"
    FAIL=$((FAIL + 1))
fi

if echo "$circular_output" | grep -q "R4 = no"; then
    echo "PASS: test_equal(foo,bar) = no"
    PASS=$((PASS + 1))
else
    echo "FAIL: test_equal(foo,bar) (expected: R4 = no)"
    FAIL=$((FAIL + 1))
fi

if echo "$circular_output" | grep -q "R5 = yes"; then
    echo "PASS: test_self_equal(f(a,b)) = yes"
    PASS=$((PASS + 1))
else
    echo "FAIL: test_self_equal(f(a,b)) (expected: R5 = yes)"
    FAIL=$((FAIL + 1))
fi

if echo "$circular_output" | grep -q "X = hello"; then
    echo "PASS: show(hello,X) = hello"
    PASS=$((PASS + 1))
else
    echo "FAIL: show(hello,X) (expected: X = hello)"
    FAIL=$((FAIL + 1))
fi

# Test ground and equality on actual circular terms
circular_ops_output=$($DART run "$REPL" <<CIRCULAR_OPS
$GLP_DIR/circular_test.glp
link(A, f(B?)), link(B, f(A?)), test_ground(A?, R1), test_eq(A?, A?, R2).
:quit
CIRCULAR_OPS
2>&1)

if echo "$circular_ops_output" | grep -q "R1 = yes"; then
    echo "PASS: ground(circular_term) = yes"
    PASS=$((PASS + 1))
else
    echo "FAIL: ground(circular_term) (expected: R1 = yes)"
    FAIL=$((FAIL + 1))
fi

if echo "$circular_ops_output" | grep -q "R2 = yes"; then
    echo "PASS: circular_term =?= circular_term = yes"
    PASS=$((PASS + 1))
else
    echo "FAIL: circular_term =?= circular_term (expected: R2 = yes)"
    FAIL=$((FAIL + 1))
fi

# Multi-arity predicate tests (sum/2 calls sum/3, reverse/2 calls reverse/3, etc.)
echo ""
echo "--- Multi-Arity Predicate Tests ---"

multi_arity_output=$($DART run "$REPL" <<MULTI_ARITY
$GLP_DIR/sum_acc.glp
$GLP_DIR/reverse_acc.glp
$GLP_DIR/length_acc.glp
sum([1,2,3,4,5], S1).
reverse([1,2,3], R1).
length([a,b,c,d], N1).
:quit
MULTI_ARITY
2>&1)

if echo "$multi_arity_output" | grep -q "S1 = 15"; then
    echo "PASS: sum/2 with accumulator = 15"
    PASS=$((PASS + 1))
else
    echo "FAIL: sum/2 with accumulator (expected: S1 = 15)"
    FAIL=$((FAIL + 1))
fi

if echo "$multi_arity_output" | grep -q "R1 = \[3, 2, 1\]"; then
    echo "PASS: reverse/2 with accumulator = [3,2,1]"
    PASS=$((PASS + 1))
else
    echo "FAIL: reverse/2 with accumulator (expected: R1 = [3, 2, 1])"
    FAIL=$((FAIL + 1))
fi

if echo "$multi_arity_output" | grep -q "N1 = 4"; then
    echo "PASS: length/2 with accumulator = 4"
    PASS=$((PASS + 1))
else
    echo "FAIL: length/2 with accumulator (expected: N1 = 4)"
    FAIL=$((FAIL + 1))
fi

# Arithmetic guards imply groundness tests
# X? < Y? can only succeed if X and Y are ground, so multiple reader occurrences allowed
echo ""
echo "--- Arithmetic Guards Imply Groundness Tests ---"

arith_ground_output=$($DART run "$REPL" <<ARITH_GROUND
$GLP_DIR/arith_guard_ground.glp
compare_and_use(3, 5, R1).
max(7, 4, M1).
in_range(5, 1, 10, R2).
in_range(15, 1, 10, R3).
compare_expr(1, 5, R4).
:quit
ARITH_GROUND
2>&1)

if echo "$arith_ground_output" | grep -q "R1 = pair(3, 5)"; then
    echo "PASS: compare_and_use(3, 5, R) = pair(3, 5)"
    PASS=$((PASS + 1))
else
    echo "FAIL: compare_and_use(3, 5, R) (expected: R1 = pair(3, 5))"
    FAIL=$((FAIL + 1))
fi

if echo "$arith_ground_output" | grep -q "M1 = 7"; then
    echo "PASS: max(7, 4, M) = 7"
    PASS=$((PASS + 1))
else
    echo "FAIL: max(7, 4, M) (expected: M1 = 7)"
    FAIL=$((FAIL + 1))
fi

if echo "$arith_ground_output" | grep -q "R2 = yes"; then
    echo "PASS: in_range(5, 1, 10, R) = yes"
    PASS=$((PASS + 1))
else
    echo "FAIL: in_range(5, 1, 10, R) (expected: R2 = yes)"
    FAIL=$((FAIL + 1))
fi

if echo "$arith_ground_output" | grep -q "R3 = no"; then
    echo "PASS: in_range(15, 1, 10, R) = no"
    PASS=$((PASS + 1))
else
    echo "FAIL: in_range(15, 1, 10, R) (expected: R3 = no)"
    FAIL=$((FAIL + 1))
fi

if echo "$arith_ground_output" | grep -q "R4 = pair(1, 5)"; then
    echo "PASS: compare_expr(1, 5, R) with X?+1 < Y?*2 = pair(1, 5)"
    PASS=$((PASS + 1))
else
    echo "FAIL: compare_expr(1, 5, R) (expected: R4 = pair(1, 5))"
    FAIL=$((FAIL + 1))
fi

# Arithmetic comparison operators (=:=, =\=, <, >, =<, >=) regression tests
echo ""
echo "--- Arithmetic Comparison Operators Tests ---"

arith_cmp_output=$($DART run "$REPL" <<ARITH_CMP
$GLP_DIR/arith_comparison.glp
arith_eq(5, 5, R1).
arith_eq(5, 3, R2).
arith_neq(5, 3, R3).
arith_neq(5, 5, R4).
expr_eq(4, 6, R5).
test_lt(3, 5, R6).
test_gt(5, 3, R7).
test_le(5, 5, R8).
test_ge(3, 5, R9).
:quit
ARITH_CMP
2>&1)

if echo "$arith_cmp_output" | grep -q "R1 = equal"; then
    echo "PASS: =:= equals (5 =:= 5)"
    PASS=$((PASS + 1))
else
    echo "FAIL: =:= equals (expected: R1 = equal)"
    FAIL=$((FAIL + 1))
fi

if echo "$arith_cmp_output" | grep -q "R2 = not_equal"; then
    echo "PASS: =:= not equals via otherwise (5 =:= 3)"
    PASS=$((PASS + 1))
else
    echo "FAIL: =:= not equals via otherwise (expected: R2 = not_equal)"
    FAIL=$((FAIL + 1))
fi

if echo "$arith_cmp_output" | grep -q "R3 = not_equal"; then
    echo "PASS: =\\= not equals (5 =\\= 3)"
    PASS=$((PASS + 1))
else
    echo "FAIL: =\\= not equals (expected: R3 = not_equal)"
    FAIL=$((FAIL + 1))
fi

if echo "$arith_cmp_output" | grep -q "R4 = equal"; then
    echo "PASS: =\\= equals via otherwise (5 =\\= 5)"
    PASS=$((PASS + 1))
else
    echo "FAIL: =\\= equals via otherwise (expected: R4 = equal)"
    FAIL=$((FAIL + 1))
fi

if echo "$arith_cmp_output" | grep -q "R5 = equal"; then
    echo "PASS: =:= with expressions (4+1 =:= 6-1)"
    PASS=$((PASS + 1))
else
    echo "FAIL: =:= with expressions (expected: R5 = equal)"
    FAIL=$((FAIL + 1))
fi

if echo "$arith_cmp_output" | grep -q "R6 = yes"; then
    echo "PASS: < comparison (3 < 5)"
    PASS=$((PASS + 1))
else
    echo "FAIL: < comparison (expected: R6 = yes)"
    FAIL=$((FAIL + 1))
fi

if echo "$arith_cmp_output" | grep -q "R7 = yes"; then
    echo "PASS: > comparison (5 > 3)"
    PASS=$((PASS + 1))
else
    echo "FAIL: > comparison (expected: R7 = yes)"
    FAIL=$((FAIL + 1))
fi

if echo "$arith_cmp_output" | grep -q "R8 = yes"; then
    echo "PASS: =< comparison (5 =< 5)"
    PASS=$((PASS + 1))
else
    echo "FAIL: =< comparison (expected: R8 = yes)"
    FAIL=$((FAIL + 1))
fi

if echo "$arith_cmp_output" | grep -q "R9 = no"; then
    echo "PASS: >= comparison fails (3 >= 5)"
    PASS=$((PASS + 1))
else
    echo "FAIL: >= comparison fails (expected: R9 = no)"
    FAIL=$((FAIL + 1))
fi

# Otherwise guard regression tests
echo ""
echo "--- Otherwise Guard Tests ---"

otherwise_output=$($DART run "$REPL" <<OTHERWISE
$GLP_DIR/otherwise_guard.glp
classify(5, R1).
classify(-3, R2).
classify(0, R3).
grade(95, G1).
grade(75, G2).
grade(55, G3).
type_of(42, T1).
type_of(hello, T2).
:quit
OTHERWISE
2>&1)

if echo "$otherwise_output" | grep -q "R1 = positive"; then
    echo "PASS: otherwise - classify 5 as positive"
    PASS=$((PASS + 1))
else
    echo "FAIL: otherwise - classify 5 (expected: R1 = positive)"
    FAIL=$((FAIL + 1))
fi

if echo "$otherwise_output" | grep -q "R2 = negative"; then
    echo "PASS: otherwise - classify -3 as negative"
    PASS=$((PASS + 1))
else
    echo "FAIL: otherwise - classify -3 (expected: R2 = negative)"
    FAIL=$((FAIL + 1))
fi

if echo "$otherwise_output" | grep -q "R3 = zero"; then
    echo "PASS: otherwise - classify 0 as zero (default)"
    PASS=$((PASS + 1))
else
    echo "FAIL: otherwise - classify 0 (expected: R3 = zero)"
    FAIL=$((FAIL + 1))
fi

if echo "$otherwise_output" | grep -q "G1 = a"; then
    echo "PASS: otherwise - grade 95 = a"
    PASS=$((PASS + 1))
else
    echo "FAIL: otherwise - grade 95 (expected: G1 = a)"
    FAIL=$((FAIL + 1))
fi

if echo "$otherwise_output" | grep -q "G2 = c"; then
    echo "PASS: otherwise - grade 75 = c"
    PASS=$((PASS + 1))
else
    echo "FAIL: otherwise - grade 75 (expected: G2 = c)"
    FAIL=$((FAIL + 1))
fi

if echo "$otherwise_output" | grep -q "G3 = f"; then
    echo "PASS: otherwise - grade 55 = f (default)"
    PASS=$((PASS + 1))
else
    echo "FAIL: otherwise - grade 55 (expected: G3 = f)"
    FAIL=$((FAIL + 1))
fi

if echo "$otherwise_output" | grep -q "T1 = integer"; then
    echo "PASS: otherwise - type_of 42 = integer"
    PASS=$((PASS + 1))
else
    echo "FAIL: otherwise - type_of 42 (expected: T1 = integer)"
    FAIL=$((FAIL + 1))
fi

if echo "$otherwise_output" | grep -q "T2 = atom"; then
    echo "PASS: otherwise - type_of hello = atom"
    PASS=$((PASS + 1))
else
    echo "FAIL: otherwise - type_of hello (expected: T2 = atom)"
    FAIL=$((FAIL + 1))
fi

# Difference list syntax (H\T) regression tests
echo ""
echo "--- Difference List Syntax Tests ---"

dl_output=$($DART run "$REPL" <<DIFF_LIST
$GLP_DIR/diff_list.glp
dl_append([1,2|T]\\T, [3,4|U]\\U, R).
dl_to_list([a,b,c]\\[], L).
:quit
DIFF_LIST
2>&1)

# Test that dl_append parses and executes (produces a \(...) structure)
if echo "$dl_output" | grep -q 'R = \\'; then
    echo "PASS: dl_append with H\\T syntax parses and executes"
    PASS=$((PASS + 1))
else
    echo "FAIL: dl_append with H\\T syntax (expected: R = \\(...))"
    FAIL=$((FAIL + 1))
fi

# Test dl_to_list conversion
if echo "$dl_output" | grep -q "L = \[a, b, c\]"; then
    echo "PASS: dl_to_list converts difference list to regular list"
    PASS=$((PASS + 1))
else
    echo "FAIL: dl_to_list conversion (expected: L = [a, b, c])"
    FAIL=$((FAIL + 1))
fi

# Test parsing of simple H\T term
simple_dl_output=$($DART run "$REPL" <<SIMPLE_DL
X = foo\\bar.
:quit
SIMPLE_DL
2>&1)

if echo "$simple_dl_output" | grep -q 'X = \\(foo, bar)'; then
    echo "PASS: Simple H\\T term parses as \\(H, T) structure"
    PASS=$((PASS + 1))
else
    echo "FAIL: Simple H\\T term (expected: X = \\(foo, bar))"
    FAIL=$((FAIL + 1))
fi

# Guard reader occurrence tests
# Per spec: guard reader occurrences count toward SRSW validation.
# A reader in a guard satisfies the reader requirement for its paired writer.
echo ""
echo "--- Guard Reader Occurrence Tests ---"

guard_reader_output=$($DART run "$REPL" <<GUARD_READER
$GLP_DIR/guard_reader.glp
guard_known(hello).
guard_ground(42).
guard_int(7).
guard_compare(3, 5).
:quit
GUARD_READER
2>&1)

# Check that file loaded successfully (no SRSW errors)
if echo "$guard_reader_output" | grep -q "Loaded.*guard_reader.glp"; then
    echo "PASS: guard_reader.glp loads (guard readers count for SRSW)"
    PASS=$((PASS + 1))
else
    echo "FAIL: guard_reader.glp should load without SRSW errors"
    FAIL=$((FAIL + 1))
fi

# Check that guard_known succeeds
if echo "$guard_reader_output" | grep -q "guard_known(hello)"; then
    echo "PASS: guard_known(hello) with known/1 guard"
    PASS=$((PASS + 1))
else
    echo "FAIL: guard_known(hello) (expected: succeeds)"
    FAIL=$((FAIL + 1))
fi

# Check that guard_ground succeeds
if echo "$guard_reader_output" | grep -q "guard_ground(42)"; then
    echo "PASS: guard_ground(42) with ground/1 guard"
    PASS=$((PASS + 1))
else
    echo "FAIL: guard_ground(42) (expected: succeeds)"
    FAIL=$((FAIL + 1))
fi

# Check that guard_compare succeeds
if echo "$guard_reader_output" | grep -q "guard_compare(3, 5)"; then
    echo "PASS: guard_compare(3,5) with X?<Y? guard"
    PASS=$((PASS + 1))
else
    echo "FAIL: guard_compare(3,5) (expected: succeeds)"
    FAIL=$((FAIL + 1))
fi

TOTAL=$((PASS + FAIL))

echo ""
echo "======================================"
echo "Total: $TOTAL | Passed: $PASS | Failed: $FAIL"
echo "======================================"

if [ $FAIL -eq 0 ]; then
    echo "ALL TESTS PASSED!"
    exit 0
else
    echo "SOME TESTS FAILED"
    exit 1
fi
